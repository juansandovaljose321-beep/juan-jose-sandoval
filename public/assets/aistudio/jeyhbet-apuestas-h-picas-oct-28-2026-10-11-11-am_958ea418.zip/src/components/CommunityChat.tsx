import React, { useState, useRef, useEffect } from 'react';
import { User, ChatMessage } from '../types';
import { getCaracasTime } from '../utils/formatters';
import { 
  MessageCircle, Send, Crown, Sparkles, X, ChevronDown, 
  Smile, ShieldCheck, Heart 
} from 'lucide-react';

interface CommunityChatProps {
  currentUser: User | null;
  messages: ChatMessage[];
  onSendMessage: (text: string, horsePicked?: number) => void;
  isOpen: boolean;
  onToggle: () => void;
  onOpenAuth: () => void;
}

const QUICK_COMMENTS = [
  '¡Le voy al #1 Rojo!',
  '¡Vamos con todo!',
  '¡Cobré mi jugada!',
  '¡Fuerza al #2 Amarillo!',
  '¡Qué buena carrera!',
  '¡Atentos a la partida!',
  '¡Suerte a todos!',
];

export const CommunityChat: React.FC<CommunityChatProps> = ({
  currentUser,
  messages,
  onSendMessage,
  isOpen,
  onToggle,
  onOpenAuth,
}) => {
  const [inputText, setInputText] = useState('');
  const [selectedHorseTag, setSelectedHorseTag] = useState<number | undefined>(undefined);
  const messagesEndRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    if (isOpen) {
      messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages, isOpen]);

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) {
      onOpenAuth();
      return;
    }
    const trimmed = inputText.trim();
    if (!trimmed) return;

    onSendMessage(trimmed, selectedHorseTag);
    setInputText('');
    setSelectedHorseTag(undefined);
  };

  const handleQuickSend = (text: string) => {
    if (!currentUser) {
      onOpenAuth();
      return;
    }
    onSendMessage(text, selectedHorseTag);
  };

  return (
    <>
      {/* Floating Chat Trigger Button (bottom-right) */}
      {!isOpen && (
        <button
          onClick={onToggle}
          className="fixed bottom-20 right-4 z-40 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-racing font-extrabold p-3 sm:px-4 sm:py-2.5 rounded-2xl shadow-2xl flex items-center gap-2 transition-all active:scale-95 border-2 border-slate-950"
          title="Abrir Chat de la Comunidad"
        >
          <div className="relative">
            <MessageCircle className="w-5 h-5 fill-current" />
            <span className="absolute -top-1 -right-1 w-2.5 h-2.5 rounded-full bg-emerald-400 border border-slate-950 animate-ping" />
          </div>
          <span className="hidden sm:inline text-xs uppercase tracking-wider">
            Chat en Vivo ({messages.length})
          </span>
        </button>
      )}

      {/* Slide-in Chat Drawer / Card */}
      {isOpen && (
        <div className="fixed bottom-20 right-2 sm:right-4 z-40 w-[94vw] sm:w-96 max-w-sm h-[480px] bg-slate-900 border-2 border-amber-500/50 rounded-3xl shadow-2xl flex flex-col overflow-hidden ring-4 ring-amber-400/20 animate-in slide-in-from-bottom-5">
          {/* Top Bar */}
          <div className="p-3.5 bg-slate-950 border-b border-slate-800 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse" />
              <span className="font-racing font-extrabold text-sm text-white uppercase tracking-wider">
                CHAT DE LA COMUNIDAD EN VIVO
              </span>
            </div>

            <button
              onClick={onToggle}
              className="p-1 rounded-lg text-slate-400 hover:text-white bg-slate-900 border border-slate-800"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Quick Notice */}
          <div className="px-3 py-1.5 bg-amber-500/10 border-b border-amber-500/20 text-[10px] text-amber-300 font-medium flex items-center justify-between">
            <span>Comparte tus pronósticos y celebra tus victorias</span>
            <span className="font-bold">Hora Caracas</span>
          </div>

          {/* Messages Feed */}
          <div className="flex-1 overflow-y-auto p-3 space-y-2.5 bg-slate-950/60">
            {messages.length === 0 ? (
              <div className="text-center py-12 space-y-2">
                <MessageCircle className="w-8 h-8 text-slate-600 mx-auto" />
                <p className="text-xs text-slate-400 font-racing">¡Sé el primero en comentar en la sala!</p>
                <div className="flex flex-wrap gap-1 justify-center pt-2">
                  {QUICK_COMMENTS.slice(0, 3).map(qc => (
                    <button
                      key={qc}
                      onClick={() => handleQuickSend(qc)}
                      className="text-[10px] bg-slate-800 text-amber-300 px-2 py-1 rounded-lg border border-slate-700 hover:bg-slate-700 font-medium"
                    >
                      {qc}
                    </button>
                  ))}
                </div>
              </div>
            ) : (
              messages.map(msg => {
                const isOwner = msg.userRole === 'admin';
                const isMe = msg.userId === currentUser?.id;

                return (
                  <div
                    key={msg.id}
                    className={`flex flex-col text-xs rounded-xl p-2.5 space-y-1 transition-all ${
                      isOwner
                        ? 'bg-amber-950/40 border border-amber-500/40 shadow-sm'
                        : isMe
                        ? 'bg-slate-800/80 border border-slate-700'
                        : 'bg-slate-900/90 border border-slate-800/80'
                    }`}
                  >
                    <div className="flex items-center justify-between gap-1">
                      <div className="flex items-center gap-1.5 truncate">
                        {isOwner ? (
                          <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded bg-amber-500 text-slate-950 font-bold text-[9px] font-racing uppercase tracking-wider">
                            <Crown className="w-2.5 h-2.5 fill-current" />
                            <span>PROPIETARIO</span>
                          </span>
                        ) : (
                          <span className="font-bold text-slate-300 font-racing truncate max-w-[120px]">
                            {msg.userName}
                          </span>
                        )}

                        {msg.horsePicked && (
                          <span className="text-[9px] px-1 py-0.2 rounded bg-slate-800 text-amber-400 font-bold font-mono">
                            #Caballo {msg.horsePicked}
                          </span>
                        )}
                      </div>

                      <span className="text-[9px] text-slate-500 font-mono shrink-0">
                        {msg.timeStr}
                      </span>
                    </div>

                    <p className={`text-xs break-words leading-relaxed ${isOwner ? 'text-amber-200 font-medium' : 'text-slate-200'}`}>
                      {msg.text}
                    </p>
                  </div>
                );
              })
            )}
            <div ref={messagesEndRef} />
          </div>

          {/* Quick Comment Chips */}
          <div className="px-2 py-1.5 bg-slate-950 border-t border-slate-800/80 flex items-center gap-1 overflow-x-auto text-xs">
            {QUICK_COMMENTS.map(qc => (
              <button
                key={qc}
                type="button"
                onClick={() => handleQuickSend(qc)}
                className="text-[10px] bg-slate-900 text-slate-300 hover:text-white hover:bg-slate-800 px-2 py-0.5 rounded-md border border-slate-800 shrink-0 font-medium transition-colors"
              >
                {qc}
              </button>
            ))}
          </div>

          {/* Input & Form */}
          <form onSubmit={handleSend} className="p-2.5 bg-slate-950 border-t border-slate-800 flex items-center gap-2">
            <input
              type="text"
              maxLength={140}
              placeholder={currentUser ? "Escribe un comentario..." : "Inicia sesión para comentar..."}
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              className="flex-1 bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-amber-400 font-sans"
            />

            <button
              type="submit"
              disabled={!inputText.trim() && !currentUser}
              className="p-2 rounded-xl bg-amber-500 hover:bg-amber-400 disabled:opacity-50 text-slate-950 font-bold transition-colors shrink-0 shadow"
              title="Enviar comentario"
            >
              <Send className="w-4 h-4" />
            </button>
          </form>
        </div>
      )}
    </>
  );
};
