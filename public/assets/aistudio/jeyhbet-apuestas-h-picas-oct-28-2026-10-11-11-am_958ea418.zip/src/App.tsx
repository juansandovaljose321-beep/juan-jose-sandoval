import React, { useState, useEffect } from 'react';
import { 
  User, Horse, BetTicket, Transaction, PlatformConfig, BetSelection, BankAccount,
  RaceHistoryRecord, ChatMessage
} from './types';
import { 
  getStoredUsers, saveStoredUsers, getCurrentUser, setCurrentUser as persistCurrentUser,
  getStoredConfig, saveStoredConfig, getStoredHorses, saveStoredHorses,
  getStoredTickets, saveStoredTickets, getStoredTransactions, saveStoredTransactions,
  getStoredRaceHistory, addRaceHistoryRecord, getStoredChatMessages, addChatMessage,
  cycleHorsesForNextRace, OWNER_USER
} from './utils/storage';
import { formatBs, getNextRaceSchedule, getCaracasTime } from './utils/formatters';

// Components
import { Header } from './components/Header';
import { BottomNav } from './components/BottomNav';
import { RaceCanvas55s } from './components/RaceCanvas55s';
import { BettingBoard } from './components/BettingBoard';
import { DepositModal } from './components/DepositModal';
import { WithdrawModal } from './components/WithdrawModal';
import { OwnerAdminPanel } from './components/OwnerAdminPanel';
import { AuthModals } from './components/AuthModals';
import { ProfileModal } from './components/ProfileModal';
import { TicketHistory } from './components/TicketHistory';
import { PWAInstallPrompt } from './components/PWAInstallPrompt';
import { RaceHistoryModal } from './components/RaceHistoryModal';
import { CommunityChat } from './components/CommunityChat';

import { 
  Play, Timer, Shield, AlertTriangle, ArrowRight, MessageCircle, 
  HelpCircle, Sparkles, RefreshCw, Smartphone, Trophy, Moon
} from 'lucide-react';

export default function App() {
  // --- Global Application State ---
  const [users, setUsers] = useState<User[]>(getStoredUsers);
  const [currentUser, setCurrentUserState] = useState<User | null>(getCurrentUser);
  const [config, setConfigState] = useState<PlatformConfig>(getStoredConfig);
  const [horses, setHorsesState] = useState<Horse[]>(getStoredHorses);
  const [tickets, setTicketsState] = useState<BetTicket[]>(getStoredTickets);
  const [transactions, setTransactionsState] = useState<Transaction[]>(getStoredTransactions);
  const [raceHistory, setRaceHistory] = useState<RaceHistoryRecord[]>(getStoredRaceHistory);
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>(getStoredChatMessages);

  // Active Navigation & Modals
  const [activeTab, setActiveTab] = useState<'apostar' | 'carrera' | 'tickets' | 'cuenta' | 'admin'>('apostar');
  const [isDepositOpen, setIsDepositOpen] = useState(false);
  const [depositDefaultAmount, setDepositDefaultAmount] = useState<number>(50);
  const [isWithdrawOpen, setIsWithdrawOpen] = useState(false);
  const [isAuthOpen, setIsAuthOpen] = useState(false);
  const [isProfileOpen, setIsProfileOpen] = useState(false);
  const [isHistoryOpen, setIsHistoryOpen] = useState(false);
  const [isChatOpen, setIsChatOpen] = useState(false);
  const [impersonatingRealAdmin, setImpersonatingRealAdmin] = useState<User | null>(null);

  // Race Simulation State
  const [isRacing, setIsRacing] = useState(false);
  const [manualWinnerOverride, setManualWinnerOverride] = useState<number | null>(null);

  // Countdown timer to next scheduled race (Caracas time)
  const [scheduleInfo, setScheduleInfo] = useState(getNextRaceSchedule());

  useEffect(() => {
    const timer = setInterval(() => {
      setScheduleInfo(getNextRaceSchedule());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  // Update State & Persistence Wrappers
  const handleSetCurrentUser = (user: User | null) => {
    setCurrentUserState(user);
    persistCurrentUser(user);
  };

  const handleUpdateConfig = (newConfig: PlatformConfig) => {
    setConfigState(newConfig);
    saveStoredConfig(newConfig);
  };

  const handleUpdateHorses = (newHorses: Horse[]) => {
    setHorsesState(newHorses);
    saveStoredHorses(newHorses);
  };

  const handleUpdateUsers = (newUsers: User[]) => {
    setUsers(newUsers);
    saveStoredUsers(newUsers);
    if (currentUser) {
      const freshCurrent = newUsers.find(u => u.id === currentUser.id);
      if (freshCurrent) handleSetCurrentUser(freshCurrent);
    }
  };

  const handleUpdateTickets = (newTickets: BetTicket[]) => {
    setTicketsState(newTickets);
    saveStoredTickets(newTickets);
  };

  const handleUpdateTransactions = (newTransactions: Transaction[]) => {
    setTransactionsState(newTransactions);
    saveStoredTransactions(newTransactions);
  };

  // --- Betting Logic ---
  const handlePlaceBet = (selections: BetSelection[], totalStake: number) => {
    if (!currentUser) {
      setIsAuthOpen(true);
      return { success: false, error: 'Debes iniciar sesión.' };
    }

    if (scheduleInfo.isNightClosed) {
      return { 
        success: false, 
        error: '🌙 El hipódromo cerró automáticamente a las 10:01 PM por horario nocturno. Las taquillas y carreras reabrirán mañana a las 09:00 AM (Zona Caracas).' 
      };
    }

    if (currentUser.balance < totalStake) {
      return { success: false, error: 'Saldo insuficiente.' };
    }

    // Deduct user balance
    const updatedUser: User = {
      ...currentUser,
      balance: currentUser.balance - totalStake,
    };

    // Update in users list
    const updatedUsers = users.map(u => u.id === currentUser.id ? updatedUser : u);
    handleUpdateUsers(updatedUsers);

    // Create Ticket
    const ticketNum = `TKT-${Math.floor(100000 + Math.random() * 900000)}`;
    const newTicket: BetTicket = {
      id: `tkt_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
      ticketNumber: ticketNum,
      userId: currentUser.id,
      userName: `${currentUser.name} ${currentUser.lastName}`,
      raceId: `race_${config.currentRaceNumber}`,
      raceNumber: config.currentRaceNumber,
      selections,
      totalStakeBs: totalStake,
      totalPotentialWinBs: selections.reduce((s, sel) => s + sel.potentialWinBs, 0),
      status: 'pendiente',
      createdAt: Date.now(),
    };

    handleUpdateTickets([newTicket, ...tickets]);

    // Create Transaction Record
    const newTx: Transaction = {
      id: `tx_${Date.now()}`,
      userId: currentUser.id,
      userName: `${currentUser.name} ${currentUser.lastName}`,
      type: 'apuesta',
      amountBs: totalStake,
      status: 'aprobado',
      note: `Ticket ${ticketNum} (Carrera #${config.currentRaceNumber})`,
      createdAt: Date.now(),
    };
    handleUpdateTransactions([newTx, ...transactions]);

    // Update horse bets pool
    const updatedHorses = horses.map(h => {
      const match = selections.find(s => s.horseNumber === h.number);
      if (match) {
        return {
          ...h,
          totalBetsBs: h.totalBetsBs + match.stakeBs,
          betCount: h.betCount + 1,
        };
      }
      return h;
    });
    handleUpdateHorses(updatedHorses);

    return { success: true };
  };

  // --- Start 30s Race ---
  const handleStartRace = (selectedWinner: number | null = null) => {
    if (isRacing) return;
    const target = selectedWinner || config.chosenWinnerHorseNumber || null;
    setManualWinnerOverride(target);
    setIsRacing(true);
    setActiveTab('carrera'); // Switch to live race view
  };

  // --- Live Community Chat Message Handler ---
  const handleSendChatMessage = (text: string, horsePicked?: number) => {
    if (!currentUser) {
      setIsAuthOpen(true);
      return;
    }
    const { timeStr } = getCaracasTime();
    const newMsg: ChatMessage = {
      id: `msg_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
      userId: currentUser.id,
      userName: `${currentUser.name} ${currentUser.lastName}`.trim(),
      userRole: currentUser.role,
      text,
      timeStr,
      timestamp: Date.now(),
      horsePicked,
    };
    const updated = addChatMessage(newMsg);
    setChatMessages(updated);
  };

  // --- Race Finish Callback ---
  const handleRaceFinish = (winnerHorseNumber: number) => {
    setIsRacing(false);

    const winningHorse = horses.find(h => h.number === winnerHorseNumber) || horses[0];
    const nextSchedule = getNextRaceSchedule();
    const { timeStr, dateStr } = getCaracasTime();

    const lastWinnerData = {
      raceNumber: config.currentRaceNumber,
      horseNumber: winningHorse.number,
      horseName: winningHorse.name,
      colorName: winningHorse.colorName,
      colorHex: winningHorse.colorHex,
      multiplier: winningHorse.currentMultiplier,
      nextRaceTimeStr: nextSchedule.nextSlotStr,
      nextRaceNotice: `Espera a la siguiente carrera a las ${nextSchedule.nextSlotStr} (Zona horaria Caracas)`,
      timestamp: Date.now(),
    };

    // Settle all pending tickets for current race
    let totalPaidToWinners = 0;
    const userWinningsMap: Record<string, number> = {};

    const updatedTickets = tickets.map(ticket => {
      if (ticket.status === 'pendiente' && ticket.raceNumber === config.currentRaceNumber) {
        // Check if any selection chose the winning horse
        const winningSelection = ticket.selections.find(s => s.horseNumber === winnerHorseNumber);

        if (winningSelection) {
          const payout = winningSelection.potentialWinBs;
          totalPaidToWinners += payout;
          userWinningsMap[ticket.userId] = (userWinningsMap[ticket.userId] || 0) + payout;

          return {
            ...ticket,
            status: 'ganado' as const,
            winningHorseNumber: winnerHorseNumber,
            totalPaidBs: payout,
          };
        } else {
          return {
            ...ticket,
            status: 'perdido' as const,
            winningHorseNumber: winnerHorseNumber,
          };
        }
      }
      return ticket;
    });

    handleUpdateTickets(updatedTickets);

    // Save official winner into Race History Database
    const historyRecord: RaceHistoryRecord = {
      id: `rec_${Date.now()}_${winnerHorseNumber}`,
      raceNumber: config.currentRaceNumber,
      winnerHorseNumber: winningHorse.number,
      winnerHorseName: winningHorse.name,
      winnerColorName: winningHorse.colorName,
      winnerColorHex: winningHorse.colorHex,
      multiplier: winningHorse.currentMultiplier,
      timeCaracas: timeStr,
      dateCaracas: dateStr,
      timestamp: Date.now(),
      totalPoolBs: winningHorse.totalBetsBs,
      totalPaidBs: totalPaidToWinners,
    };
    const updatedHistory = addRaceHistoryRecord(historyRecord);
    setRaceHistory(updatedHistory);

    // Broadcast winner notice into Community Chat
    const chatBroadcast: ChatMessage = {
      id: `chat_win_${Date.now()}`,
      userId: 'system',
      userName: 'OFICIAL JEYHBET',
      userRole: 'admin',
      text: `🏆 ¡OFICIAL! Carrera #${config.currentRaceNumber} ganada por el Caballo Nº ${winningHorse.number} ${winningHorse.name.toUpperCase()} (${winningHorse.colorName}) pagando x${winningHorse.currentMultiplier}. Próxima carrera: ${nextSchedule.nextSlotStr}.`,
      timeStr,
      timestamp: Date.now(),
      horsePicked: winningHorse.number,
    };
    const nextChat = addChatMessage(chatBroadcast);
    setChatMessages(nextChat);

    // Credit winners' balances
    if (Object.keys(userWinningsMap).length > 0) {
      const updatedUsers = users.map(u => {
        if (userWinningsMap[u.id]) {
          return {
            ...u,
            balance: u.balance + userWinningsMap[u.id],
          };
        }
        return u;
      });
      handleUpdateUsers(updatedUsers);

      // Create transactions for prizes
      const newPrizeTxs: Transaction[] = Object.entries(userWinningsMap).map(([uId, amount]) => {
        const u = users.find(usr => usr.id === uId);
        return {
          id: `tx_prize_${Date.now()}_${uId}`,
          userId: uId,
          userName: u ? `${u.name} ${u.lastName}` : 'Jugador Ganador',
          type: 'premio',
          amountBs: amount,
          status: 'aprobado',
          note: `Premio Carrera #${config.currentRaceNumber} - Caballo #${winnerHorseNumber}`,
          createdAt: Date.now(),
        };
      });
      handleUpdateTransactions([...newPrizeTxs, ...transactions]);
    }

    // Advance Race Number and cycle names / odds
    const nextRaceNum = config.currentRaceNumber + 1;
    handleUpdateConfig({
      ...config,
      currentRaceNumber: nextRaceNum,
      oddsRoundCounter: config.oddsRoundCounter + 1,
      lastRaceWinner: lastWinnerData,
    });

    // Rotate horses and reset bets for the new race
    const nextHorses = cycleHorsesForNextRace(nextRaceNum);
    handleUpdateHorses(nextHorses);
  };

  // --- Deposits & Withdrawals ---
  const handleSubmitDeposit = (amountBs: number, reference: string, captureUrl?: string, bankName?: string) => {
    if (!currentUser) return;

    const newTx: Transaction = {
      id: `tx_dep_${Date.now()}`,
      userId: currentUser.id,
      userName: `${currentUser.name} ${currentUser.lastName}`,
      type: 'deposito',
      amountBs,
      status: 'pendiente', // Owner must verify or approve
      reference,
      captureUrl,
      bankDetails: {
        bankName: bankName || 'Banco de Venezuela',
        cedula: currentUser.cedula,
        phone: currentUser.phone,
      },
      createdAt: Date.now(),
    };

    handleUpdateTransactions([newTx, ...transactions]);
  };

  const handleApproveDeposit = (transactionId: string) => {
    const tx = transactions.find(t => t.id === transactionId);
    if (!tx || tx.status !== 'pendiente') return;

    // Credit the player's account
    const targetUser = users.find(u => u.id === tx.userId);
    if (targetUser) {
      const updatedUser: User = {
        ...targetUser,
        balance: targetUser.balance + tx.amountBs,
      };
      const updatedUsers = users.map(u => u.id === tx.userId ? updatedUser : u);
      handleUpdateUsers(updatedUsers);
    }

    // Mark transaction as approved
    const updatedTxs = transactions.map(t => 
      t.id === transactionId ? { ...t, status: 'aprobado' as const } : t
    );
    handleUpdateTransactions(updatedTxs);
  };

  const handleRejectDeposit = (transactionId: string) => {
    const updatedTxs = transactions.map(t => 
      t.id === transactionId ? { ...t, status: 'rechazado' as const } : t
    );
    handleUpdateTransactions(updatedTxs);
  };

  const handleProcessWithdrawal = (amountBs: number, account: BankAccount) => {
    if (!currentUser) return { success: false, error: 'No autenticado.' };
    if (currentUser.balance < amountBs) return { success: false, error: 'Saldo insuficiente.' };

    // Deduct immediately from user balance
    const updatedUser: User = {
      ...currentUser,
      balance: currentUser.balance - amountBs,
    };
    const updatedUsers = users.map(u => u.id === currentUser.id ? updatedUser : u);
    handleUpdateUsers(updatedUsers);

    // Create withdrawal transaction
    const newTx: Transaction = {
      id: `tx_wth_${Date.now()}`,
      userId: currentUser.id,
      userName: `${currentUser.name} ${currentUser.lastName}`,
      type: 'retiro',
      amountBs,
      status: 'pendiente', // Owner must transfer
      bankDetails: {
        bankName: account.bankName,
        cedula: account.cedula,
        phone: account.phone,
      },
      createdAt: Date.now(),
    };
    handleUpdateTransactions([newTx, ...transactions]);

    return { success: true };
  };

  const handlePayWithdrawal = (transactionId: string) => {
    const updatedTxs = transactions.map(t => 
      t.id === transactionId ? { ...t, status: 'aprobado' as const } : t
    );
    handleUpdateTransactions(updatedTxs);
  };

  // Add Bank Account to User
  const handleAddBankAccount = (bankData: Omit<BankAccount, 'id'>) => {
    if (!currentUser) return;
    const newAccount: BankAccount = {
      ...bankData,
      id: `bnk_${Date.now()}`,
    };
    const updatedUser: User = {
      ...currentUser,
      bankAccounts: [...currentUser.bankAccounts, newAccount],
    };
    const updatedUsers = users.map(u => u.id === currentUser.id ? updatedUser : u);
    handleUpdateUsers(updatedUsers);
  };

  // Impersonate / Assist User Flow
  const handleImpersonateUser = (targetUser: User) => {
    if (currentUser?.role === 'admin') {
      setImpersonatingRealAdmin(currentUser);
      handleSetCurrentUser(targetUser);
      setActiveTab('apostar');
    }
  };

  const handleReturnToAdmin = () => {
    if (impersonatingRealAdmin) {
      handleSetCurrentUser(impersonatingRealAdmin);
      setImpersonatingRealAdmin(null);
      setActiveTab('admin');
    }
  };

  // Format countdown string
  const formatCountdown = (totalSec: number) => {
    const m = Math.floor(totalSec / 60);
    const s = totalSec % 60;
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  const userTickets = tickets.filter(t => t.userId === currentUser?.id);
  const userTransactions = transactions.filter(t => t.userId === currentUser?.id);
  const pendingTicketsCount = userTickets.filter(t => t.status === 'pendiente').length;

  return (
    <div className="min-h-screen bg-[#070b14] text-slate-100 flex flex-col font-sans selection:bg-amber-500 selection:text-slate-950 pb-20 sm:pb-12">
      {/* Impersonation Banner if Owner is inside a player's account */}
      {impersonatingRealAdmin && (
        <div className="sticky top-0 z-50 bg-amber-500 text-slate-950 font-bold px-4 py-2 text-xs flex items-center justify-between shadow-lg">
          <div className="flex items-center gap-2">
            <Shield className="w-4 h-4" />
            <span>
              MODO ASISTENCIA ACTIVO: Viendo la cuenta de <strong>{currentUser?.name} {currentUser?.lastName}</strong> ({currentUser?.cedula})
            </span>
          </div>
          <button
            onClick={handleReturnToAdmin}
            className="px-3 py-1 bg-slate-950 text-amber-400 rounded-lg text-xs font-racing uppercase tracking-wider hover:bg-slate-900 transition-colors"
          >
            Regresar al Panel Propietario
          </button>
        </div>
      )}

      {/* Main Top Header */}
      <Header
        currentUser={currentUser}
        config={config}
        onOpenDeposit={() => {
          setDepositDefaultAmount(50);
          setIsDepositOpen(true);
        }}
        onOpenWithdraw={() => setIsWithdrawOpen(true)}
        onOpenAuth={() => setIsAuthOpen(true)}
        onOpenProfile={() => setIsProfileOpen(true)}
        onOpenAdmin={() => setActiveTab('admin')}
        onOpenHistory={() => setIsHistoryOpen(true)}
        onOpenChat={() => setIsChatOpen(!isChatOpen)}
      />

      {/* Main Vertical Responsive Container */}
      <main className="flex-1 max-w-4xl w-full mx-auto px-3 sm:px-6 py-4 space-y-4">
        {/* PWA In-App Install Prompt Banner */}
        <PWAInstallPrompt />

        {/* Next Scheduled Race Countdown & Status Banner */}
        <div className={`bg-gradient-to-r ${scheduleInfo.isNightClosed ? 'from-indigo-950/90 via-slate-950 to-indigo-950/90 border-indigo-700/60' : 'from-slate-900 via-slate-950 to-slate-900 border-slate-800'} border rounded-2xl p-3.5 flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-md`}>
          <div className="flex items-center gap-3">
            <div className={`w-10 h-10 rounded-xl ${scheduleInfo.isNightClosed ? 'bg-indigo-500/20 text-indigo-400 border border-indigo-500/40' : 'bg-amber-500/10 border border-amber-500/30 text-amber-400'} flex items-center justify-center shrink-0`}>
              {scheduleInfo.isNightClosed ? <Moon className="w-5 h-5" /> : <Timer className="w-5 h-5" />}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-racing font-extrabold text-base text-white uppercase tracking-wide">
                  {scheduleInfo.isNightClosed ? 'CERRADO (10:01 PM - 09:00 AM)' : `PRÓXIMA CARRERA OFICIAL: ${scheduleInfo.nextSlotStr}`}
                </span>
                <span className={`text-[10px] ${scheduleInfo.isNightClosed ? 'bg-indigo-900/60 text-indigo-300 border border-indigo-700/50' : 'bg-slate-800 text-amber-400'} font-mono font-bold px-2 py-0.5 rounded`}>
                  {scheduleInfo.isNightClosed ? 'Reapertura Mañana 09:00 AM' : `Carrera #${config.currentRaceNumber}`}
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-0.5">
                {scheduleInfo.nextRaceTimeNotice}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2.5 self-end sm:self-center">
            <div className="text-right">
              <span className="text-[10px] text-slate-400 block font-medium">
                {scheduleInfo.isNightClosed ? 'Reapertura En:' : 'Cuenta Regresiva:'}
              </span>
              <span className="text-lg font-mono font-extrabold text-amber-400 tracking-wider">
                {formatCountdown(scheduleInfo.secondsRemaining)}
              </span>
            </div>

            {/* Quick Historial Button */}
            <button
              type="button"
              onClick={() => setIsHistoryOpen(true)}
              className="py-2 px-3 rounded-xl bg-slate-800/90 hover:bg-slate-700 text-amber-400 border border-amber-500/30 font-racing font-bold text-xs uppercase flex items-center gap-1.5 transition-colors shadow"
              title="Ver Historial de Ganadores"
            >
              <Trophy className="w-3.5 h-3.5 text-amber-400" />
              <span className="hidden sm:inline">Historial</span>
            </button>

            {/* Only Owner can start races */}
            {currentUser?.role === 'admin' && (
              <button
                type="button"
                disabled={isRacing}
                onClick={() => handleStartRace(null)}
                className="py-2 px-3 rounded-xl bg-gradient-to-r from-emerald-500 to-emerald-600 hover:from-emerald-400 hover:to-emerald-500 text-slate-950 font-racing font-extrabold text-xs uppercase tracking-wider flex items-center gap-1.5 shadow-md transition-transform active:scale-95 disabled:opacity-50"
                title="Control del Propietario: Iniciar carrera en tiempo real de 30 segundos"
              >
                <Play className="w-3.5 h-3.5 fill-current" />
                <span>{isRacing ? 'Corriendo (30s)...' : 'Lanzar Carrera (30s)'}</span>
              </button>
            )}
          </div>
        </div>

        {/* Tab View: APOSTAR (Tablero + Carreras) */}
        {activeTab === 'apostar' && (
          <div className="space-y-4">
            {/* Live 30s Race Track Preview / Running View */}
            <RaceCanvas55s
              horses={horses}
              isRacing={isRacing}
              onRaceFinish={handleRaceFinish}
              predeterminedWinner={manualWinnerOverride || config.chosenWinnerHorseNumber || null}
              raceNumber={config.currentRaceNumber}
            />

            {/* Persistent Winner Announcement Banner (Only during operating daytime hours) */}
            {!scheduleInfo.isNightClosed && config.lastRaceWinner && (
              <div className="p-4 bg-gradient-to-r from-amber-500/20 via-slate-900 to-amber-500/10 border-2 border-amber-400/80 rounded-2xl flex flex-col sm:flex-row items-center justify-between gap-3 shadow-xl animate-in fade-in">
                <div className="flex items-center gap-3.5">
                  <div
                    className="w-14 h-14 rounded-2xl flex flex-col items-center justify-center text-white font-extrabold shadow-lg shrink-0 border-2 border-amber-400"
                    style={{ backgroundColor: config.lastRaceWinner.colorHex }}
                  >
                    <span className="text-[10px] font-bold uppercase">Nº</span>
                    <span className="text-3xl font-racing font-black leading-none">{config.lastRaceWinner.horseNumber}</span>
                  </div>
                  <div>
                    <span className="text-[11px] text-amber-400 font-racing font-bold uppercase tracking-wider block">
                      🏆 ÚLTIMO GANADOR OFICIAL · CARRERA #{config.lastRaceWinner.raceNumber}
                    </span>
                    <h4 className="text-xl font-racing font-extrabold text-white">
                      ¡GANÓ EL CABALLO Nº {config.lastRaceWinner.horseNumber} {config.lastRaceWinner.horseName.toUpperCase()}!
                    </h4>
                    <p className="text-xs text-slate-300 font-mono">
                      Color: <strong>{config.lastRaceWinner.colorName}</strong> · Cuota pagada: <strong className="text-emerald-400">x{config.lastRaceWinner.multiplier}</strong>
                    </p>
                  </div>
                </div>

                <div className="p-2.5 bg-slate-950/80 border border-amber-500/40 rounded-xl text-center sm:text-right shrink-0">
                  <span className="text-xs sm:text-sm font-racing font-bold text-amber-300 block uppercase">
                    ⏰ ESPERA A LA SIGUIENTE CARRERA A LAS {config.lastRaceWinner.nextRaceTimeStr}
                  </span>
                  <span className="text-[10px] text-slate-400 font-mono">
                    Zona Horaria Caracas
                  </span>
                </div>
              </div>
            )}

            {/* Night Closed Notice instead of premature morning winner */}
            {scheduleInfo.isNightClosed && (
              <div className="p-4 bg-gradient-to-r from-indigo-950/80 via-slate-900 to-indigo-950/80 border border-indigo-600/70 rounded-2xl flex flex-col sm:flex-row items-center justify-between gap-3 shadow-xl">
                <div className="flex items-center gap-3.5">
                  <div className="w-12 h-12 rounded-2xl bg-indigo-500/20 text-indigo-400 border border-indigo-500/40 flex items-center justify-center shrink-0">
                    <Moon className="w-6 h-6" />
                  </div>
                  <div>
                    <span className="text-[11px] text-indigo-400 font-racing font-bold uppercase tracking-wider block">
                      🌙 HIPÓDROMO CERRADO POR HORARIO NOCTURNO
                    </span>
                    <h4 className="text-base sm:text-lg font-racing font-extrabold text-white">
                      Taquillas cerradas automáticamente a las 10:01 PM
                    </h4>
                    <p className="text-xs text-slate-300">
                      No hay ganador matutino asignado hasta que se corra la primera carrera oficial mañana a las <strong>09:00 AM</strong>.
                    </p>
                  </div>
                </div>
                <button
                  onClick={() => setIsHistoryOpen(true)}
                  className="py-2 px-4 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-racing font-bold text-xs uppercase flex items-center gap-1.5 transition-colors shrink-0"
                >
                  <Trophy className="w-4 h-4" />
                  <span>Historial de Ganadores</span>
                </button>
              </div>
            )}

            {/* Hero / Promo Strip */}
            <div className="relative rounded-2xl overflow-hidden border border-slate-800 bg-slate-900 shadow-lg">
              <div className="flex flex-col md:flex-row items-center justify-between p-4 sm:p-5 gap-4">
                <div className="space-y-1.5 max-w-lg">
                  <span className="text-xs font-bold text-amber-400 tracking-wider font-racing uppercase flex items-center gap-1.5">
                    <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                    <span>Plataforma Oficial de Hipismo Venezolano</span>
                  </span>
                  <h2 className="text-xl sm:text-2xl font-extrabold text-white font-racing tracking-wide leading-tight">
                    CARRERAS EN VIVO Y APUESTAS EN BOLÍVARES
                  </h2>
                  <p className="text-xs text-slate-300 leading-relaxed">
                    6 caballos en pista en tiempo real. Multiplicadores dinámicos que aumentan cada 5 rondas. Recargas y retiros directos por Pago Móvil.
                  </p>
                </div>

                <div className="shrink-0 flex items-center gap-2">
                  {!currentUser ? (
                    <button
                      type="button"
                      onClick={() => setIsAuthOpen(true)}
                      className="py-2.5 px-4 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs uppercase font-racing tracking-wider shadow-md transition-all"
                    >
                      Registrarse para Apostar
                    </button>
                  ) : (
                    <button
                      type="button"
                      onClick={() => {
                        setDepositDefaultAmount(100);
                        setIsDepositOpen(true);
                      }}
                      className="py-2.5 px-4 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs uppercase font-racing tracking-wider shadow-md transition-all"
                    >
                      Recargar Saldo (Bs)
                    </button>
                  )}
                </div>
              </div>
            </div>

            {/* Betting Board */}
            <BettingBoard
              horses={horses}
              currentUser={currentUser}
              config={config}
              allTickets={tickets}
              isNightClosed={scheduleInfo.isNightClosed}
              onPlaceBet={handlePlaceBet}
              onOpenDeposit={(needed) => {
                setDepositDefaultAmount(needed || 50);
                setIsDepositOpen(true);
              }}
              onOpenAuth={() => setIsAuthOpen(true)}
            />
          </div>
        )}

        {/* Tab View: EN VIVO / CARRERA */}
        {activeTab === 'carrera' && (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-xl font-extrabold text-white font-racing">
                  HIPÓDROMO EN TIEMPO REAL
                </h3>
                <p className="text-xs text-slate-400">
                  Carreras de 30 segundos con física realista, jinetes con chaquetillas oficiales y foto finish.
                </p>
              </div>

              {currentUser?.role === 'admin' && !isRacing && (
                <button
                  type="button"
                  onClick={() => handleStartRace(null)}
                  className="py-2 px-3.5 bg-emerald-600 hover:bg-emerald-500 text-slate-950 font-extrabold text-xs rounded-xl uppercase font-racing flex items-center gap-1.5 shadow-lg transition-transform active:scale-95"
                  title="Control del Propietario: Iniciar Carrera (30s)"
                >
                  <Play className="w-3.5 h-3.5 fill-current" />
                  <span>Iniciar Carrera (Propietario)</span>
                </button>
              )}
            </div>

            <RaceCanvas55s
              horses={horses}
              isRacing={isRacing}
              onRaceFinish={handleRaceFinish}
              predeterminedWinner={manualWinnerOverride || config.chosenWinnerHorseNumber || null}
              raceNumber={config.currentRaceNumber}
            />

            {/* Winner Announcement Card */}
            {!scheduleInfo.isNightClosed && config.lastRaceWinner && (
              <div className="p-4 bg-gradient-to-r from-amber-500/20 via-slate-900 to-amber-500/10 border-2 border-amber-400/80 rounded-2xl flex flex-col sm:flex-row items-center justify-between gap-3 shadow-xl animate-in fade-in">
                <div className="flex items-center gap-3.5">
                  <div
                    className="w-14 h-14 rounded-2xl flex flex-col items-center justify-center text-white font-extrabold shadow-lg shrink-0 border-2 border-amber-400"
                    style={{ backgroundColor: config.lastRaceWinner.colorHex }}
                  >
                    <span className="text-[10px] font-bold uppercase">Nº</span>
                    <span className="text-3xl font-racing font-black leading-none">{config.lastRaceWinner.horseNumber}</span>
                  </div>
                  <div>
                    <span className="text-[11px] text-amber-400 font-racing font-bold uppercase tracking-wider block">
                      🏆 ÚLTIMO GANADOR OFICIAL · CARRERA #{config.lastRaceWinner.raceNumber}
                    </span>
                    <h4 className="text-xl font-racing font-extrabold text-white">
                      ¡GANÓ EL CABALLO Nº {config.lastRaceWinner.horseNumber} {config.lastRaceWinner.horseName.toUpperCase()}!
                    </h4>
                    <p className="text-xs text-slate-300 font-mono">
                      Color: <strong>{config.lastRaceWinner.colorName}</strong> · Cuota pagada: <strong className="text-emerald-400">x{config.lastRaceWinner.multiplier}</strong>
                    </p>
                  </div>
                </div>

                <div className="p-2.5 bg-slate-950/80 border border-amber-500/40 rounded-xl text-center sm:text-right shrink-0">
                  <span className="text-xs sm:text-sm font-racing font-bold text-amber-300 block uppercase">
                    ⏰ ESPERA A LA SIGUIENTE CARRERA A LAS {config.lastRaceWinner.nextRaceTimeStr}
                  </span>
                  <span className="text-[10px] text-slate-400 font-mono">
                    Zona Horaria Caracas
                  </span>
                </div>
              </div>
            )}

            {/* Night Closed Notice */}
            {scheduleInfo.isNightClosed && (
              <div className="p-4 bg-gradient-to-r from-indigo-950/80 via-slate-900 to-indigo-950/80 border border-indigo-600/70 rounded-2xl flex flex-col sm:flex-row items-center justify-between gap-3 shadow-xl">
                <div className="flex items-center gap-3.5">
                  <div className="w-12 h-12 rounded-2xl bg-indigo-500/20 text-indigo-400 border border-indigo-500/40 flex items-center justify-center shrink-0">
                    <Moon className="w-6 h-6" />
                  </div>
                  <div>
                    <span className="text-[11px] text-indigo-400 font-racing font-bold uppercase tracking-wider block">
                      🌙 HIPÓDROMO CERRADO POR HORARIO NOCTURNO
                    </span>
                    <h4 className="text-base sm:text-lg font-racing font-extrabold text-white">
                      Taquillas cerradas automáticamente a las 10:01 PM
                    </h4>
                    <p className="text-xs text-slate-300">
                      No hay carreras activas durante la noche. Las partidas se reanudan mañana a las <strong>09:00 AM</strong>.
                    </p>
                  </div>
                </div>
                <button
                  onClick={() => setIsHistoryOpen(true)}
                  className="py-2 px-4 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-racing font-bold text-xs uppercase flex items-center gap-1.5 transition-colors shrink-0"
                >
                  <Trophy className="w-4 h-4" />
                  <span>Historial de Ganadores</span>
                </button>
              </div>
            )}

            {/* Odds Table */}
            <div className="p-4 bg-slate-900 rounded-2xl border border-slate-800 space-y-3">
              <h4 className="font-racing font-bold text-white text-base">
                DIVIDENDOS Y CUOTAS OFICIALES · CARRERA #{config.currentRaceNumber}
              </h4>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 text-xs">
                {horses.map(h => (
                  <div key={h.number} className="p-2.5 bg-slate-950 rounded-xl border border-slate-800 flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className="w-6 h-6 rounded-md text-white font-bold text-xs flex items-center justify-center font-racing" style={{ backgroundColor: h.colorHex }}>
                        {h.number}
                      </span>
                      <span className="font-bold text-white">{h.name}</span>
                    </div>
                    <span className="font-mono font-bold text-amber-400">x{h.currentMultiplier}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Tab View: MIS TICKETS */}
        {activeTab === 'tickets' && (
          <div className="space-y-4">
            <div>
              <h3 className="text-xl font-extrabold text-white font-racing">
                HISTORIAL DE JUGADAS Y PREMIOS
              </h3>
              <p className="text-xs text-slate-400">
                Consulta todos tus tickets jugados, premios cobrados y estado en tiempo real.
              </p>
            </div>

            <TicketHistory tickets={userTickets} />
          </div>
        )}

        {/* Tab View: MI CUENTA */}
        {activeTab === 'cuenta' && (
          <div className="space-y-4">
            <div>
              <h3 className="text-xl font-extrabold text-white font-racing">
                MI CUENTA Y CONFIGURACIÓN
              </h3>
              <p className="text-xs text-slate-400">
                Gestiona tus datos personales, cuentas de Pago Móvil y transacciones.
              </p>
            </div>

            {currentUser ? (
              <div className="space-y-4">
                {/* Balance and Actions Card */}
                <div className="p-5 bg-gradient-to-br from-slate-900 to-slate-950 rounded-3xl border border-amber-500/30 shadow-xl space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <span className="text-xs text-slate-400 block">Saldo Disponible para Jugar:</span>
                      <span className="text-3xl font-extrabold text-amber-400 font-mono">
                        {formatBs(currentUser.balance)}
                      </span>
                    </div>

                    <div className="flex gap-2">
                      <button
                        onClick={() => {
                          setDepositDefaultAmount(50);
                          setIsDepositOpen(true);
                        }}
                        className="py-2 px-3.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs rounded-xl uppercase font-racing shadow"
                      >
                        Recargar
                      </button>
                      <button
                        onClick={() => setIsWithdrawOpen(true)}
                        className="py-2 px-3.5 bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs rounded-xl uppercase font-racing"
                      >
                        Retirar
                      </button>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 pt-2 border-t border-slate-800 text-xs">
                    <div>
                      <span className="text-slate-500 block text-[10px]">Titular:</span>
                      <span className="font-semibold text-slate-200">{currentUser.name} {currentUser.lastName}</span>
                    </div>
                    <div>
                      <span className="text-slate-500 block text-[10px]">Cédula:</span>
                      <span className="font-mono text-slate-200">{currentUser.cedula}</span>
                    </div>
                    <div>
                      <span className="text-slate-500 block text-[10px]">Teléfono:</span>
                      <span className="font-mono text-slate-200">{currentUser.phone}</span>
                    </div>
                  </div>
                </div>

                {/* WhatsApp Support Direct Button */}
                <a
                  href={`https://wa.me/584221475717?text=${encodeURIComponent(
                    `Hola Juan Sandoval, me comunico desde JeyhBet solicitando atención para mi usuario (${currentUser.name} ${currentUser.lastName}).`
                  )}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full py-3.5 px-4 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs uppercase rounded-2xl flex items-center justify-center gap-2 shadow-lg transition-colors"
                >
                  <MessageCircle className="w-5 h-5" />
                  <span>Contactar Soporte WhatsApp (+58 4221475717)</span>
                </a>

                {/* User Bank Accounts Summary */}
                <div className="p-4 bg-slate-900 rounded-2xl border border-slate-800 space-y-3">
                  <div className="flex items-center justify-between">
                    <h4 className="font-racing font-bold text-white text-base">
                      CUENTAS DE PAGO MÓVIL REGISTRADAS
                    </h4>
                    <button
                      onClick={() => setIsWithdrawOpen(true)}
                      className="text-xs text-amber-400 hover:underline font-semibold"
                    >
                      Gestionar Cuentas
                    </button>
                  </div>

                  <div className="space-y-2 text-xs">
                    {currentUser.bankAccounts.map(acc => (
                      <div key={acc.id} className="p-3 bg-slate-950 rounded-xl border border-slate-800 flex justify-between">
                        <div>
                          <span className="font-bold text-white block">{acc.bankName}</span>
                          <span className="text-[11px] text-slate-400">C.I: {acc.cedula} · Tel: {acc.phone}</span>
                        </div>
                        <span className="text-[10px] text-emerald-400 font-bold self-center">Verificada</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            ) : (
              <div className="p-8 text-center bg-slate-900 rounded-3xl border border-slate-800 space-y-3">
                <div className="w-14 h-14 rounded-2xl bg-amber-500/10 border border-amber-500/30 text-amber-400 flex items-center justify-center mx-auto">
                  <HelpCircle className="w-7 h-7" />
                </div>
                <h4 className="text-lg font-bold text-white font-racing">INICIA SESIÓN EN TU CUENTA</h4>
                <p className="text-xs text-slate-400 max-w-sm mx-auto">
                  Para acceder a tu saldo, gestionar tus bancos y ver tus tickets, inicia sesión con tus credenciales.
                </p>
                <button
                  type="button"
                  onClick={() => setIsAuthOpen(true)}
                  className="py-2.5 px-6 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs uppercase font-racing"
                >
                  Iniciar Sesión / Registrarse
                </button>
              </div>
            )}
          </div>
        )}

        {/* Tab View: ADMIN (Owner Control Panel) */}
        {activeTab === 'admin' && (
          <OwnerAdminPanel
            currentUser={currentUser}
            config={config}
            horses={horses}
            users={users}
            tickets={tickets}
            transactions={transactions}
            onUpdateConfig={handleUpdateConfig}
            onUpdateHorses={handleUpdateHorses}
            onStartRaceManual={handleStartRace}
            onApproveDeposit={handleApproveDeposit}
            onRejectDeposit={handleRejectDeposit}
            onPayWithdrawal={handlePayWithdrawal}
            onEditUser={(updated) => {
              const next = users.map(u => u.id === updated.id ? updated : u);
              handleUpdateUsers(next);
            }}
            onImpersonateUser={handleImpersonateUser}
            onClosePanel={() => setActiveTab('apostar')}
          />
        )}
      </main>

      {/* Floating Bottom Navigation */}
      <BottomNav
        activeTab={activeTab}
        onChangeTab={setActiveTab}
        currentUser={currentUser}
        pendingTicketsCount={pendingTicketsCount}
      />

      {/* Modals */}
      <DepositModal
        isOpen={isDepositOpen}
        onClose={() => setIsDepositOpen(false)}
        currentUser={currentUser}
        config={config}
        defaultAmount={depositDefaultAmount}
        onSubmitDeposit={handleSubmitDeposit}
      />

      <WithdrawModal
        isOpen={isWithdrawOpen}
        onClose={() => setIsWithdrawOpen(false)}
        currentUser={currentUser}
        onAddBankAccount={handleAddBankAccount}
        onProcessWithdrawal={handleProcessWithdrawal}
      />

      <AuthModals
        isOpen={isAuthOpen}
        onClose={() => setIsAuthOpen(false)}
        existingUsers={users}
        onLoginSuccess={handleSetCurrentUser}
        onRegisterSuccess={(newUser) => {
          handleUpdateUsers([...users, newUser]);
        }}
        onPasswordResetSuccess={(email, newPass) => {
          const updatedUsers = users.map(u => 
            u.email.toLowerCase() === email.toLowerCase() ? { ...u, password: newPass } : u
          );
          handleUpdateUsers(updatedUsers);
        }}
      />

      <ProfileModal
        isOpen={isProfileOpen}
        onClose={() => setIsProfileOpen(false)}
        currentUser={currentUser}
        userTickets={userTickets}
        userTransactions={userTransactions}
        onAddBankAccount={handleAddBankAccount}
        onLogout={() => handleSetCurrentUser(null)}
        supportPhone={config.supportPhoneWhatsApp}
      />

      {/* Official Race Winners History Modal */}
      <RaceHistoryModal
        isOpen={isHistoryOpen}
        onClose={() => setIsHistoryOpen(false)}
        historyRecords={raceHistory}
      />

      {/* Live Interactive Community Chat */}
      <CommunityChat
        currentUser={currentUser}
        messages={chatMessages}
        onSendMessage={handleSendChatMessage}
        isOpen={isChatOpen}
        onToggle={() => setIsChatOpen(!isChatOpen)}
        onOpenAuth={() => setIsAuthOpen(true)}
      />
    </div>
  );
}
